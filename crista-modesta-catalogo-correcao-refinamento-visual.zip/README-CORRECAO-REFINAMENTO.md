# Correção do refinamento visual

## Problema corrigido

O `globals.css` do refinamento anterior continha apenas os estilos adicionais e
substituiu acidentalmente o CSS-base do catálogo.

Esta correção:

- restaura todo o CSS-base;
- mantém o refinamento cristão;
- recupera as grades, fotos, coleções, espaçamentos e responsividade;
- restaura os contêineres com posição válida para `next/image fill`;
- autoriza as qualidades 75, 90 e 92 no Next.js.

## Instalação

Extraia na raiz:

E:\Projetos\crista-modesta-catalogo

Confirme a substituição de:

- src/app/globals.css
- next.config.ts

Depois execute:

Remove-Item -Recurse -Force .next -ErrorAction SilentlyContinue
npm run lint
npm run build
npm run dev
